class QuizFile:
	original_questions = {
		"The language spoken by the people by Pakistan is ?" : 
			['Sindhi', 'Hindi', 'Palauan', 'Nauruan'],
		"The World Largest desert is ?" :
			['Sahara', 'Thar', 'Kalahari', 'Sonaran'],
		"Country that has the highest in Barley Production ?":
			['Russia', 'China', 'India', 'France'],
		"The metal whose salts are sensitive to light is ?" :
			['Silver', 'Zinc', 'Copper', 'Aluminium'],
		"The Central Rice Research Station is situated in ?" :
			['Cuttack', 'Chennai', 'Bangalore', 'Quilon'],
		"Mount Everest is located in ?" :
			['Nepal', 'India', 'Tibet', 'China'],
		"Which soil is suitable for agriculture ?" :
			['Peaty Soil', 'Red Soil', 'Black Soil', 'Sand'],
		"Black soils are best suited for the cultivation of ?" :
			['Cotton', 'Rice', 'Cereals', 'Sugarcane'],
		"The device used for measuring altitudes is ?" :
			['Altmeter', 'Ammeter', 'Audiometer', 'Galvanometer'],
		"Which is considered as the biggest port of India ?" :
			['Mumbai', 'Chennai', 'Kolkata', 'Cochin'],
			
		"The gas used for making vegetables is ?" :
			['Hydrogen', 'Oxygen', 'Carbon dioxide', 'Nitrogen'],
		"The chief ore of Aluminium is ?" :
			['Bauxite', 'Iron', 'Cryolite', 'Haematite'],
		"Country that was called as Land of Rising Sun ?" :
			['Japan', 'Russia', 'Korea', 'Holland'],
		"Pink city in India is ?" :
			['Jaipur', 'Mysore', 'Hyderabad', 'Karnataka'],
		"Deficiency of Iron leads to ?" :
			['Anaemia', 'Malaria', 'Dental Cavity', 'Rickets']

	}